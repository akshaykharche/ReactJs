# Building Applications with React and Flux on Pluralsight
Final version of demo app for [Building Applications with React and Flux on Pluralsight](https://app.pluralsight.com/library/courses/react-flux-building-applications/table-of-contents)
